tp @s 0 -60 0
tellraw @s "SG:WinnerMessage"
scoreboard players set $GameActive __variable__ 0